p3.b
